﻿/*Задача 38: Задайте массив вещественных чисел. 
Найдите разницу между максимальным и минимальным элементов массива.

[3 7 22 2 78] -> 76
*/

Console.WriteLine("Введите количество чисел массива: ");
int size = Convert.ToInt32(Console.ReadLine());
int[] array = new int[size];

void GetArray(int[] array)
{
    int index = 0;
    Random rnd = new Random();

    for (int i = index; i < array.Length; i++)
{
    array[i] = rnd.Next(1, 100);
    index++;
    Console.Write($"{array[i]} ");
    }
    Console.WriteLine();
}

int GetMaxNumber(int[] array)
{
    
    int index = 0;
    int max = array[0];
    for (int i = index; i <  array.Length; i++)
    {
        if (max < array[i]) max = array[i]; 
        index++;
    }
    
    Console.WriteLine($"Максимальное число в массиве {max}");

    return max;
}

int GetMinNumber(int[] array)

{
    int index = 0;
    int min = array[0];
    for (int i = index; i <  array.Length; i++)
    {
        if (min > array[i]) min = array[i]; 
        index++;
    }
    
    Console.WriteLine($"Минимальное число в массиве {min}");

    return min;
}


GetArray(array);

int max = GetMaxNumber(array);
int min = GetMinNumber(array);
int result = max - min;
Console.WriteLine($"Разница между максимальным числом {max} и минимальным числом {min} = {result}");





