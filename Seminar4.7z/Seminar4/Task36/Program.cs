﻿/*Задача 36: Задайте одномерный массив, заполненный случайными числами. 
Найдите сумму элементов, стоящих на нечётных позициях.

[3, 7, 23, 12] -> 19

[-4, -6, 89, 6] -> 0
*/

Console.WriteLine("Введите количество элементов массива");
int size = Convert.ToInt32(Console.ReadLine());
int[] array = new int[size]; 

void CreatArray(int[] array)
{
    int index = 0;
    Random rnd = new Random();

    for (int i = index; i < array.Length; i++ )
    {
        array[i] = rnd.Next(1, 1000);
        index++;
        Console.Write($"{array[i]} ");
    }
    Console.WriteLine();
}

void SumOddNumber(int[] array)
{
int sum = 0;

for (int i = 0; i < array.Length; i+=2)
    sum = sum + array[i];

    Console.WriteLine($"всего {array.Length} чисел, сумма чисел cтоящих на нечётных позициях = {sum}");

}

CreatArray(array);
SumOddNumber(array);



